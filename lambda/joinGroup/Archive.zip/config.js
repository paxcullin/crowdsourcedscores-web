const config = {
    username: 'pcsm-user',
    password: '*dZ2HaWN'
}

module.exports = { config }